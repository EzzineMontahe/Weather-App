package com.montahe.weatherapp;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class ForecastData {
    @SerializedName("list")
    public List<ForecastItem> list;

    @SerializedName("city")
    public City city;

    public static class ForecastItem {
        @SerializedName("dt_txt")
        public String date;

        @SerializedName("main")
        public Main main;

        @SerializedName("weather")
        public List<Weather> weather;

        @SerializedName("wind")
        public Wind wind;
    }

    public static class City {
        @SerializedName("name")
        public String name;
    }

    public static class Main {
        @SerializedName("temp")
        public double temp;

        @SerializedName("humidity")
        public int humidity;
    }

    public static class Weather {
        @SerializedName("main")
        public String main;

        @SerializedName("icon")
        public String icon;
    }

    public static class Wind {
        @SerializedName("speed")
        public double speed;
    }
}